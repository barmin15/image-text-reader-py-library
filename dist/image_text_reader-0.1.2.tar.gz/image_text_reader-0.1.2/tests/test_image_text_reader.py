import unittest
from image_text_reader import image_text_reader

class TestImageTextReader(unittest.TestCase):
    def test_example(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
