from .image_text_reader import ocr_image
